/**
 *  Interfaces to remote objects for the Game of Rope.
 *
 *    Communication is based on Java RMI.
 */

package interfaces;
