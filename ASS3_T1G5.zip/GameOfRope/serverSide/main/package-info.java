/**
 * Package that contains the main programs of the server side.
 */
package serverSide.main;
