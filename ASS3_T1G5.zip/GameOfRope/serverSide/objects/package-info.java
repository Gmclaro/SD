
/**
 * Package that contains the shared regions.
 */

package serverSide.objects;