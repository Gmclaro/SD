/**
 *   This package contains the classes that are used to create the client side of the application.
 */

package clientSide;
