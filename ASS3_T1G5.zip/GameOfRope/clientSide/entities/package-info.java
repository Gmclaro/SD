/**
 * Package with the classes of the entities.
 */
package clientSide.entities;
