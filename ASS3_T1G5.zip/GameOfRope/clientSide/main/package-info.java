
/**
 * This package contains the main class of the client side of the application.
 */
package clientSide.main;
