/**
 *   Common infrastructure.
 */

package commonInfra;
